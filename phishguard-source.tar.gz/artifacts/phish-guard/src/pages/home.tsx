import React, { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Link } from "wouter";
import { ScanSearch, AlertTriangle, ShieldCheck, AlertOctagon, Link as LinkIcon, ArrowRight, Activity, Globe } from "lucide-react";
import { useCreateScan, useListScans } from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Form, FormControl, FormField, FormItem, FormMessage } from "@/components/ui/form";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Skeleton } from "@/components/ui/skeleton";
import { format } from "date-fns";

const scanSchema = z.object({
  url: z.string().url({ message: "Please enter a valid URL." }),
});

function ScanResultDisplay({ scan }: { scan: any }) {
  if (!scan) return null;

  const isPhishing = scan.verdict === "phishing";
  const isSuspicious = scan.verdict === "suspicious";
  const isSafe = scan.verdict === "safe";

  const getStatusColor = () => {
    if (isPhishing) return "text-destructive border-destructive/20 bg-destructive/10";
    if (isSuspicious) return "text-amber-600 border-amber-500/20 bg-amber-500/10";
    return "text-emerald-600 border-emerald-500/20 bg-emerald-500/10";
  };

  const getProgressColor = () => {
    if (isPhishing) return "[&>div]:bg-destructive";
    if (isSuspicious) return "[&>div]:bg-amber-500";
    return "[&>div]:bg-emerald-500";
  };

  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <Card className="overflow-hidden border-2 shadow-sm">
        <div className={`h-2 w-full ${isPhishing ? "bg-destructive" : isSuspicious ? "bg-amber-500" : "bg-emerald-500"}`} />
        <CardContent className="p-6 md:p-8">
          <div className="flex flex-col md:flex-row gap-8 items-start md:items-center">
            
            <div className="flex-1 space-y-2">
              <div className="flex items-center gap-2 text-muted-foreground font-medium text-sm mb-2">
                <Globe className="w-4 h-4" />
                {scan.domain}
              </div>
              <h2 className="text-xl md:text-2xl font-semibold break-all text-foreground leading-tight">
                {scan.url}
              </h2>
              <div className="flex items-center gap-3 pt-2">
                <Badge variant="outline" className={`px-3 py-1 text-sm font-semibold uppercase tracking-wide border-2 ${getStatusColor()}`}>
                  {isPhishing && <AlertOctagon className="w-4 h-4 mr-2" />}
                  {isSuspicious && <AlertTriangle className="w-4 h-4 mr-2" />}
                  {isSafe && <ShieldCheck className="w-4 h-4 mr-2" />}
                  {scan.verdict}
                </Badge>
                <span className="text-sm text-muted-foreground">
                  Scanned on {format(new Date(scan.createdAt), "MMM d, yyyy 'at' h:mm a")}
                </span>
              </div>
            </div>

            <div className="w-full md:w-48 bg-muted/50 rounded-xl p-4 border flex flex-col items-center justify-center shrink-0">
              <div className="text-sm font-semibold text-muted-foreground uppercase tracking-widest mb-1">Risk Score</div>
              <div className="text-5xl font-display font-bold tabular-nums tracking-tighter">
                {scan.riskScore}
                <span className="text-2xl text-muted-foreground">/100</span>
              </div>
              <Progress value={scan.riskScore} className={`h-2 w-full mt-4 ${getProgressColor()}`} />
            </div>

          </div>
        </CardContent>
      </Card>

      <div className="space-y-4">
        <h3 className="text-lg font-display font-semibold flex items-center gap-2">
          <Activity className="w-5 h-5 text-muted-foreground" />
          Detected Signals
        </h3>
        
        {scan.signals.length === 0 ? (
          <Card className="border-dashed">
            <CardContent className="p-8 text-center text-muted-foreground">
              <ShieldCheck className="w-12 h-12 mx-auto text-emerald-500/50 mb-3" />
              <p className="font-medium">No suspicious signals detected.</p>
              <p className="text-sm">This URL appears to be safe based on our current heuristics.</p>
            </CardContent>
          </Card>
        ) : (
          <div className="grid gap-3">
            {scan.signals.map((signal: any) => (
              <Card key={signal.id} className="overflow-hidden">
                <div className="flex items-stretch">
                  <div className={`w-1.5 shrink-0 ${
                    signal.severity === 'high' ? 'bg-destructive' : 
                    signal.severity === 'medium' ? 'bg-amber-500' : 'bg-blue-500'
                  }`} />
                  <CardContent className="p-4 flex-1 flex flex-col sm:flex-row sm:items-center gap-4">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="font-semibold text-foreground">{signal.label}</span>
                        <Badge variant="secondary" className="text-[10px] uppercase tracking-wider py-0 px-2 h-5">
                          {signal.severity}
                        </Badge>
                      </div>
                      <p className="text-sm text-muted-foreground leading-relaxed">{signal.detail}</p>
                    </div>
                  </CardContent>
                </div>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

export default function Home() {
  const [activeScan, setActiveScan] = useState<any>(null);
  const createScan = useCreateScan();
  const { data: recentScans, isLoading: isLoadingRecent } = useListScans({ limit: 3 });

  const form = useForm<z.infer<typeof scanSchema>>({
    resolver: zodResolver(scanSchema),
    defaultValues: {
      url: "",
    },
  });

  function onSubmit(values: z.infer<typeof scanSchema>) {
    createScan.mutate(
      { data: { url: values.url } },
      {
        onSuccess: (data) => {
          setActiveScan(data);
          form.reset();
        },
      }
    );
  }

  return (
    <div className="max-w-4xl mx-auto px-4 py-8 md:py-12 space-y-12">
      
      <div className="text-center space-y-4 py-8">
        <div className="inline-flex items-center justify-center p-3 bg-primary/10 rounded-2xl mb-2 text-primary">
          <ShieldCheck className="w-8 h-8" />
        </div>
        <h1 className="text-4xl md:text-5xl font-display font-bold tracking-tight text-foreground">
          Inspect any URL for <span className="text-primary">phishing risks</span>
        </h1>
        <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
          Instantly analyze domains for lookalike patterns, suspicious hosts, and dangerous heuristics.
        </p>
      </div>

      <Card className="shadow-lg border-primary/20 bg-card/50 backdrop-blur">
        <CardContent className="p-6 md:p-8">
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="flex flex-col sm:flex-row gap-4">
              <FormField
                control={form.control}
                name="url"
                render={({ field }) => (
                  <FormItem className="flex-1 space-y-0">
                    <FormControl>
                      <div className="relative">
                        <LinkIcon className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                        <Input 
                          placeholder="https://example.com/login" 
                          className="h-14 pl-12 pr-4 text-lg bg-background border-2 shadow-inner focus-visible:ring-primary"
                          {...field} 
                          disabled={createScan.isPending}
                        />
                      </div>
                    </FormControl>
                    <FormMessage className="pt-2" />
                  </FormItem>
                )}
              />
              <Button 
                type="submit" 
                size="lg" 
                className="h-14 px-8 text-lg font-semibold shrink-0 shadow-md"
                disabled={createScan.isPending}
              >
                {createScan.isPending ? (
                  <ScanSearch className="w-5 h-5 mr-2 animate-pulse" />
                ) : (
                  <ScanSearch className="w-5 h-5 mr-2" />
                )}
                {createScan.isPending ? "Analyzing..." : "Run Scan"}
              </Button>
            </form>
          </Form>
        </CardContent>
      </Card>

      {activeScan && (
        <div className="pt-8 border-t">
          <ScanResultDisplay scan={activeScan} />
        </div>
      )}

      {!activeScan && (
        <div className="pt-8 border-t">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-xl font-display font-semibold">Recent Scans</h3>
            <Link href="/history" className="text-sm font-medium text-primary hover:underline flex items-center gap-1">
              View all <ArrowRight className="w-4 h-4" />
            </Link>
          </div>
          
          {isLoadingRecent ? (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {[1, 2, 3].map(i => <Skeleton key={i} className="h-32 rounded-xl" />)}
            </div>
          ) : recentScans && recentScans.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {recentScans.map(scan => (
                <Card key={scan.id} className="cursor-pointer hover:shadow-md hover:border-primary/50 transition-all" onClick={() => setActiveScan(scan)}>
                  <CardHeader className="p-4 pb-2">
                    <div className="flex justify-between items-start">
                      <div className="text-sm font-medium text-muted-foreground truncate w-full pr-2">
                        {scan.domain}
                      </div>
                      <Badge variant="outline" className={`shrink-0 ${
                        scan.verdict === 'phishing' ? 'text-destructive border-destructive/30' :
                        scan.verdict === 'suspicious' ? 'text-amber-600 border-amber-500/30' :
                        'text-emerald-600 border-emerald-500/30'
                      }`}>
                        {scan.verdict}
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent className="p-4 pt-0 flex justify-between items-end">
                    <div className="text-sm text-muted-foreground">
                      Risk: <span className="font-semibold text-foreground">{scan.riskScore}</span>
                    </div>
                    <div className="text-xs text-muted-foreground">
                      {format(new Date(scan.createdAt), "MMM d")}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <div className="text-center p-8 bg-muted/30 rounded-xl border border-dashed">
              <p className="text-muted-foreground">No recent scans. Paste a URL above to get started.</p>
            </div>
          )}
        </div>
      )}
    </div>
  );
}