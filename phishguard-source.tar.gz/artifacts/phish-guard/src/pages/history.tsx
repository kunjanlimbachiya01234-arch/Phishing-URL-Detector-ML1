import React, { useState } from "react";
import { Link } from "wouter";
import { format } from "date-fns";
import { History as HistoryIcon, Search, Trash2, ArrowLeft, ExternalLink, ShieldCheck, AlertTriangle, AlertOctagon } from "lucide-react";
import { useListScans, useDeleteScan, useGetScan, getListScansQueryKey, getGetScanStatsQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { useToast } from "@/hooks/use-toast";
import { Progress } from "@/components/ui/progress";

export default function History() {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedScanId, setSelectedScanId] = useState<number | null>(null);
  
  const { data: scans, isLoading } = useListScans();
  const deleteScan = useDeleteScan();
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const { data: activeScan, isLoading: isLoadingScan } = useGetScan(selectedScanId || 0, {
    query: { enabled: !!selectedScanId, queryKey: ['scan', selectedScanId] }
  });

  const filteredScans = scans?.filter(scan => 
    scan.url.toLowerCase().includes(searchTerm.toLowerCase()) || 
    scan.domain.toLowerCase().includes(searchTerm.toLowerCase())
  ) || [];

  const handleDelete = (id: number) => {
    deleteScan.mutate({ id }, {
      onSuccess: () => {
        toast({ title: "Scan deleted", description: "The scan has been removed from history." });
        queryClient.invalidateQueries({ queryKey: getListScansQueryKey() });
        queryClient.invalidateQueries({ queryKey: getGetScanStatsQueryKey() });
        if (selectedScanId === id) setSelectedScanId(null);
      }
    });
  };

  const getVerdictBadge = (verdict: string) => {
    if (verdict === 'phishing') return <Badge variant="outline" className="border-destructive/30 text-destructive bg-destructive/5"><AlertOctagon className="w-3 h-3 mr-1"/> Phishing</Badge>;
    if (verdict === 'suspicious') return <Badge variant="outline" className="border-amber-500/30 text-amber-600 bg-amber-500/5"><AlertTriangle className="w-3 h-3 mr-1"/> Suspicious</Badge>;
    return <Badge variant="outline" className="border-emerald-500/30 text-emerald-600 bg-emerald-500/5"><ShieldCheck className="w-3 h-3 mr-1"/> Safe</Badge>;
  };

  return (
    <div className="max-w-6xl mx-auto px-4 py-8 space-y-8">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
        <div>
          <h1 className="text-3xl font-display font-bold tracking-tight text-foreground flex items-center gap-2">
            <HistoryIcon className="w-8 h-8 text-muted-foreground" />
            Scan History
          </h1>
          <p className="text-muted-foreground mt-1">Review past analyses and security assessments.</p>
        </div>
        <div className="relative w-full sm:w-72">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input 
            placeholder="Search domains or URLs..." 
            className="pl-9 bg-card"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
      </div>

      <Card className="shadow-sm">
        <div className="rounded-md border">
          <Table>
            <TableHeader className="bg-muted/50">
              <TableRow>
                <TableHead className="w-[300px]">URL / Domain</TableHead>
                <TableHead>Date</TableHead>
                <TableHead>Verdict</TableHead>
                <TableHead className="text-center">Risk Score</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {isLoading ? (
                Array.from({ length: 5 }).map((_, i) => (
                  <TableRow key={i}>
                    <TableCell><Skeleton className="h-5 w-48" /><Skeleton className="h-4 w-32 mt-1" /></TableCell>
                    <TableCell><Skeleton className="h-4 w-24" /></TableCell>
                    <TableCell><Skeleton className="h-6 w-20 rounded-full" /></TableCell>
                    <TableCell><Skeleton className="h-6 w-8 mx-auto" /></TableCell>
                    <TableCell><Skeleton className="h-8 w-8 ml-auto" /></TableCell>
                  </TableRow>
                ))
              ) : filteredScans.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={5} className="h-32 text-center text-muted-foreground">
                    No scans found.
                  </TableCell>
                </TableRow>
              ) : (
                filteredScans.map((scan) => (
                  <TableRow key={scan.id} className="group cursor-pointer" onClick={() => setSelectedScanId(scan.id)}>
                    <TableCell>
                      <div className="font-medium text-foreground truncate max-w-[300px]">{scan.domain}</div>
                      <div className="text-sm text-muted-foreground truncate max-w-[300px]">{scan.url}</div>
                    </TableCell>
                    <TableCell className="text-sm whitespace-nowrap text-muted-foreground">
                      {format(new Date(scan.createdAt), "MMM d, yyyy HH:mm")}
                    </TableCell>
                    <TableCell>
                      {getVerdictBadge(scan.verdict)}
                    </TableCell>
                    <TableCell className="text-center">
                      <span className={`font-semibold ${
                        scan.riskScore >= 70 ? 'text-destructive' : 
                        scan.riskScore >= 40 ? 'text-amber-600' : 'text-emerald-600'
                      }`}>
                        {scan.riskScore}
                      </span>
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex justify-end" onClick={(e) => e.stopPropagation()}>
                        <AlertDialog>
                          <AlertDialogTrigger asChild>
                            <Button variant="ghost" size="icon" className="text-muted-foreground hover:text-destructive hover:bg-destructive/10">
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </AlertDialogTrigger>
                          <AlertDialogContent>
                            <AlertDialogHeader>
                              <AlertDialogTitle>Delete scan record?</AlertDialogTitle>
                              <AlertDialogDescription>
                                This will permanently remove the scan report for {scan.domain} from your history. This action cannot be undone.
                              </AlertDialogDescription>
                            </AlertDialogHeader>
                            <AlertDialogFooter>
                              <AlertDialogCancel>Cancel</AlertDialogCancel>
                              <AlertDialogAction onClick={() => handleDelete(scan.id)} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
                                Delete
                              </AlertDialogAction>
                            </AlertDialogFooter>
                          </AlertDialogContent>
                        </AlertDialog>
                      </div>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </div>
      </Card>

      <Dialog open={!!selectedScanId} onOpenChange={(open) => !open && setSelectedScanId(null)}>
        <DialogContent className="max-w-2xl overflow-hidden p-0 gap-0">
          {isLoadingScan || !activeScan ? (
            <div className="p-8 space-y-4">
              <Skeleton className="h-8 w-3/4" />
              <Skeleton className="h-4 w-1/2" />
              <Skeleton className="h-32 w-full mt-8" />
            </div>
          ) : (
            <>
              <div className={`p-6 md:p-8 border-b ${
                activeScan.verdict === 'phishing' ? 'bg-destructive/5 border-destructive/20' :
                activeScan.verdict === 'suspicious' ? 'bg-amber-500/5 border-amber-500/20' :
                'bg-emerald-500/5 border-emerald-500/20'
              }`}>
                <div className="flex justify-between items-start mb-4">
                  {getVerdictBadge(activeScan.verdict)}
                  <div className="text-sm font-medium text-muted-foreground">
                    Score: <span className="text-lg font-bold text-foreground ml-1">{activeScan.riskScore}</span>/100
                  </div>
                </div>
                <h2 className="text-xl md:text-2xl font-semibold break-all text-foreground mb-2">
                  {activeScan.url}
                </h2>
                <div className="text-sm text-muted-foreground flex items-center gap-4">
                  <span>Domain: <span className="font-medium text-foreground">{activeScan.domain}</span></span>
                  <span>Scanned: {format(new Date(activeScan.createdAt), "MMM d, yyyy h:mm a")}</span>
                </div>
              </div>
              
              <div className="p-6 md:p-8 bg-card max-h-[60vh] overflow-y-auto">
                <h3 className="text-lg font-display font-semibold mb-4">Detected Signals</h3>
                {activeScan.signals.length === 0 ? (
                  <div className="text-center p-6 border rounded-lg bg-muted/20">
                    <p className="text-muted-foreground">No suspicious signals found for this URL.</p>
                  </div>
                ) : (
                  <div className="space-y-3">
                    {activeScan.signals.map((signal) => (
                      <div key={signal.id} className="p-4 border rounded-lg bg-background flex gap-4">
                        <div className={`w-1.5 rounded-full shrink-0 ${
                          signal.severity === 'high' ? 'bg-destructive' : 
                          signal.severity === 'medium' ? 'bg-amber-500' : 'bg-blue-500'
                        }`} />
                        <div>
                          <div className="font-semibold text-foreground flex items-center gap-2 mb-1">
                            {signal.label}
                            <Badge variant="secondary" className="text-[10px] uppercase tracking-wider py-0 px-2 h-4">
                              {signal.severity}
                            </Badge>
                          </div>
                          <p className="text-sm text-muted-foreground">{signal.detail}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
              <div className="p-4 border-t bg-muted/30 flex justify-end">
                <Button variant="outline" onClick={() => setSelectedScanId(null)}>Close</Button>
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>

    </div>
  );
}