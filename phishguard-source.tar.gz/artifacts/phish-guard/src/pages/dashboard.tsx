import React from "react";
import { LayoutDashboard, Target, ShieldAlert, ShieldCheck, AlertOctagon, Activity } from "lucide-react";
import { useGetScanStats } from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Progress } from "@/components/ui/progress";

export default function Dashboard() {
  const { data: stats, isLoading } = useGetScanStats();

  if (isLoading || !stats) {
    return (
      <div className="max-w-6xl mx-auto px-4 py-8 space-y-8">
        <div>
          <Skeleton className="h-10 w-48 mb-2" />
          <Skeleton className="h-5 w-64" />
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {[1, 2, 3, 4].map(i => <Skeleton key={i} className="h-32 rounded-xl" />)}
        </div>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <Skeleton className="h-96 rounded-xl" />
          <Skeleton className="h-96 rounded-xl" />
        </div>
      </div>
    );
  }

  const getSeverityColor = (count: number, total: number) => {
    const ratio = count / total;
    if (ratio > 0.5) return "bg-destructive";
    if (ratio > 0.2) return "bg-amber-500";
    return "bg-blue-500";
  };

  return (
    <div className="max-w-6xl mx-auto px-4 py-8 space-y-8">
      <div>
        <h1 className="text-3xl font-display font-bold tracking-tight text-foreground flex items-center gap-2">
          <LayoutDashboard className="w-8 h-8 text-muted-foreground" />
          Security Dashboard
        </h1>
        <p className="text-muted-foreground mt-1">Aggregate statistics and threat intelligence across all your scans.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="shadow-sm">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Total Scans</CardTitle>
            <Target className="w-4 h-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">{stats.totalScans}</div>
          </CardContent>
        </Card>
        
        <Card className="shadow-sm border-destructive/20 bg-destructive/5">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-destructive">Phishing Detected</CardTitle>
            <AlertOctagon className="w-4 h-4 text-destructive" />
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-destructive">{stats.phishingCount}</div>
            <p className="text-xs text-destructive/80 mt-1">
              {stats.totalScans > 0 ? Math.round((stats.phishingCount / stats.totalScans) * 100) : 0}% of total scans
            </p>
          </CardContent>
        </Card>

        <Card className="shadow-sm border-amber-500/20 bg-amber-500/5">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-amber-600">Suspicious URLs</CardTitle>
            <ShieldAlert className="w-4 h-4 text-amber-600" />
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-amber-600">{stats.suspiciousCount}</div>
            <p className="text-xs text-amber-600/80 mt-1">
              {stats.totalScans > 0 ? Math.round((stats.suspiciousCount / stats.totalScans) * 100) : 0}% of total scans
            </p>
          </CardContent>
        </Card>

        <Card className="shadow-sm border-emerald-500/20 bg-emerald-500/5">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-emerald-600">Safe URLs</CardTitle>
            <ShieldCheck className="w-4 h-4 text-emerald-600" />
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-emerald-600">{stats.safeCount}</div>
            <p className="text-xs text-emerald-600/80 mt-1">
              {stats.totalScans > 0 ? Math.round((stats.safeCount / stats.totalScans) * 100) : 0}% of total scans
            </p>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <Card className="shadow-sm">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Activity className="w-5 h-5 text-muted-foreground" />
              Top Detected Signals
            </CardTitle>
            <CardDescription>Most common security red flags across all scans</CardDescription>
          </CardHeader>
          <CardContent>
            {stats.topSignals && stats.topSignals.length > 0 ? (
              <div className="space-y-6">
                {stats.topSignals.map((signal) => (
                  <div key={signal.label} className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="font-medium text-foreground">{signal.label}</span>
                      <span className="text-muted-foreground">{signal.count} occurrences</span>
                    </div>
                    <Progress 
                      value={(signal.count / stats.totalScans) * 100} 
                      className={`h-2 [&>div]:${getSeverityColor(signal.count, stats.totalScans)}`} 
                    />
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center p-8 border border-dashed rounded-lg bg-muted/20">
                <p className="text-muted-foreground">No signals detected yet.</p>
              </div>
            )}
          </CardContent>
        </Card>

        <Card className="shadow-sm bg-sidebar text-sidebar-foreground border-sidebar-border relative overflow-hidden">
          <div className="absolute right-0 top-0 w-64 h-64 bg-sidebar-primary/10 rounded-full blur-3xl -translate-y-1/2 translate-x-1/4 pointer-events-none" />
          <CardHeader>
            <CardTitle className="text-sidebar-foreground">Global Risk Assessment</CardTitle>
            <CardDescription className="text-sidebar-foreground/70">Average risk score across all processed URLs</CardDescription>
          </CardHeader>
          <CardContent className="flex flex-col items-center justify-center p-8 min-h-[300px]">
            <div className="relative w-48 h-48 flex items-center justify-center rounded-full border-4 border-sidebar-accent shadow-inner">
              <div className="text-center">
                <div className="text-6xl font-display font-bold tabular-nums tracking-tighter text-white">
                  {Math.round(stats.avgRiskScore)}
                </div>
                <div className="text-sm text-sidebar-foreground/70 uppercase tracking-widest mt-1">Average Score</div>
              </div>
              
              {/* Decorative rings */}
              <svg className="absolute inset-0 w-full h-full -rotate-90 pointer-events-none">
                <circle
                  cx="96" cy="96" r="94"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="4"
                  strokeDasharray={`${stats.avgRiskScore * 5.9} 600`}
                  className={`${
                    stats.avgRiskScore >= 70 ? 'text-destructive' : 
                    stats.avgRiskScore >= 40 ? 'text-amber-500' : 'text-emerald-500'
                  }`}
                />
              </svg>
            </div>
            <p className="mt-8 text-center text-sidebar-foreground/80 max-w-sm">
              Your average risk score is {
                stats.avgRiskScore >= 70 ? 'critically high' : 
                stats.avgRiskScore >= 40 ? 'elevated' : 'low'
              }. {
                stats.avgRiskScore >= 70 ? 'High percentage of malicious URLs detected.' : 
                stats.avgRiskScore >= 40 ? 'Exercise caution with user-submitted links.' : 'The environment is generally safe.'
              }
            </p>
          </CardContent>
        </Card>
      </div>

    </div>
  );
}