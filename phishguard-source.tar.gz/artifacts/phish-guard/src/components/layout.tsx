import React from "react";
import { Link, useLocation } from "wouter";
import { ShieldCheck, History, LayoutDashboard, Menu } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";

export function Layout({ children }: { children: React.ReactNode }) {
  const [location] = useLocation();

  const navigation = [
    { name: "Scanner", href: "/", icon: ShieldCheck },
    { name: "History", href: "/history", icon: History },
    { name: "Dashboard", href: "/dashboard", icon: LayoutDashboard },
  ];

  return (
    <div className="min-h-screen bg-background text-foreground flex flex-col md:flex-row">
      <header className="md:hidden flex items-center justify-between px-4 py-3 border-b bg-card z-10 sticky top-0">
        <div className="flex items-center gap-2 font-display font-semibold text-lg tracking-tight">
          <div className="h-8 w-8 bg-primary rounded-md flex items-center justify-center">
            <ShieldCheck className="w-5 h-5 text-primary-foreground" />
          </div>
          PhishGuard
        </div>
        <Sheet>
          <SheetTrigger asChild>
            <Button variant="ghost" size="icon" className="md:hidden">
              <Menu className="w-5 h-5" />
            </Button>
          </SheetTrigger>
          <SheetContent side="left" className="w-64 p-0">
            <div className="flex flex-col h-full bg-sidebar text-sidebar-foreground">
              <div className="p-4 border-b border-sidebar-border flex items-center gap-3">
                <div className="h-8 w-8 bg-sidebar-primary rounded-md flex items-center justify-center">
                  <ShieldCheck className="w-5 h-5 text-sidebar-primary-foreground" />
                </div>
                <span className="font-display font-semibold text-lg tracking-tight">PhishGuard</span>
              </div>
              <nav className="flex-1 p-4 space-y-1">
                {navigation.map((item) => {
                  const isActive = location === item.href;
                  return (
                    <Link
                      key={item.name}
                      href={item.href}
                      className={`flex items-center gap-3 px-3 py-2.5 rounded-md transition-colors text-sm font-medium ${
                        isActive
                          ? "bg-sidebar-accent text-sidebar-accent-foreground"
                          : "text-sidebar-foreground/70 hover:bg-sidebar-accent/50 hover:text-sidebar-foreground"
                      }`}
                    >
                      <item.icon className="w-5 h-5" />
                      {item.name}
                    </Link>
                  );
                })}
              </nav>
            </div>
          </SheetContent>
        </Sheet>
      </header>

      <aside className="hidden md:flex w-64 flex-col bg-sidebar text-sidebar-foreground border-r border-sidebar-border sticky top-0 h-screen">
        <div className="p-6 flex items-center gap-3">
          <div className="h-10 w-10 bg-sidebar-primary rounded-lg flex items-center justify-center shadow-sm">
            <ShieldCheck className="w-6 h-6 text-sidebar-primary-foreground" />
          </div>
          <span className="font-display font-bold text-xl tracking-tight text-white">PhishGuard</span>
        </div>
        
        <div className="px-4 py-2">
          <p className="px-3 text-xs font-semibold text-sidebar-foreground/50 uppercase tracking-wider mb-2">Main Menu</p>
          <nav className="space-y-1">
            {navigation.map((item) => {
              const isActive = location === item.href;
              return (
                <Link
                  key={item.name}
                  href={item.href}
                  className={`flex items-center gap-3 px-3 py-2.5 rounded-md transition-colors text-sm font-medium ${
                    isActive
                      ? "bg-sidebar-accent text-sidebar-accent-foreground shadow-sm"
                      : "text-sidebar-foreground/70 hover:bg-sidebar-accent/50 hover:text-sidebar-foreground"
                  }`}
                >
                  <item.icon className={`w-5 h-5 ${isActive ? "text-sidebar-primary" : ""}`} />
                  {item.name}
                </Link>
              );
            })}
          </nav>
        </div>
      </aside>

      <main className="flex-1 w-full relative">
        {children}
      </main>
    </div>
  );
}