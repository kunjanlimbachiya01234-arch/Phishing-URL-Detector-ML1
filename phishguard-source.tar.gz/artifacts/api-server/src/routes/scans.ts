import { Router, type IRouter } from "express";
import { desc, eq, sql } from "drizzle-orm";
import { db, scansTable } from "@workspace/db";
import {
  CreateScanBody,
  ListScansQueryParams,
  GetScanParams,
  DeleteScanParams,
  ListScansResponse,
  CreateScanResponse,
  GetScanResponse,
  GetScanStatsResponse,
} from "@workspace/api-zod";
import { analyzeUrl } from "../lib/phishing-detector";

const router: IRouter = Router();

router.get("/scans/stats", async (_req, res): Promise<void> => {
  const [totals] = await db
    .select({
      totalScans: sql<number>`count(*)`,
      safeCount: sql<number>`count(*) filter (where ${scansTable.verdict} = 'safe')`,
      suspiciousCount: sql<number>`count(*) filter (where ${scansTable.verdict} = 'suspicious')`,
      phishingCount: sql<number>`count(*) filter (where ${scansTable.verdict} = 'phishing')`,
      avgRiskScore: sql<number>`coalesce(avg(${scansTable.riskScore}), 0)`,
    })
    .from(scansTable);

  const signalRows = await db
    .select({ signals: scansTable.signals })
    .from(scansTable);

  const counts = new Map<string, number>();
  for (const row of signalRows) {
    const signals = row.signals as { label: string }[];
    for (const signal of signals ?? []) {
      counts.set(signal.label, (counts.get(signal.label) ?? 0) + 1);
    }
  }
  const topSignals = Array.from(counts.entries())
    .map(([label, count]) => ({ label, count }))
    .sort((a, b) => b.count - a.count)
    .slice(0, 5);

  res.json(
    GetScanStatsResponse.parse({
      totalScans: Number(totals?.totalScans ?? 0),
      safeCount: Number(totals?.safeCount ?? 0),
      suspiciousCount: Number(totals?.suspiciousCount ?? 0),
      phishingCount: Number(totals?.phishingCount ?? 0),
      avgRiskScore: Number(totals?.avgRiskScore ?? 0),
      topSignals,
    }),
  );
});

router.get("/scans", async (req, res): Promise<void> => {
  const query = ListScansQueryParams.safeParse(req.query);
  if (!query.success) {
    res.status(400).json({ error: query.error.message });
    return;
  }

  const scans = await db
    .select()
    .from(scansTable)
    .orderBy(desc(scansTable.createdAt))
    .limit(query.data.limit ?? 50);

  res.json(ListScansResponse.parse(scans));
});

router.post("/scans", async (req, res): Promise<void> => {
  const parsed = CreateScanBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  let analysis;
  try {
    analysis = analyzeUrl(parsed.data.url);
  } catch (err) {
    req.log.warn({ err }, "Failed to analyze URL");
    res.status(400).json({ error: "The provided value is not a valid URL" });
    return;
  }

  const [scan] = await db
    .insert(scansTable)
    .values({
      url: parsed.data.url,
      normalizedUrl: analysis.normalizedUrl,
      domain: analysis.domain,
      verdict: analysis.verdict,
      riskScore: analysis.riskScore,
      signals: analysis.signals,
    })
    .returning();

  res.status(201).json(CreateScanResponse.parse(scan));
});

router.get("/scans/:id", async (req, res): Promise<void> => {
  const params = GetScanParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [scan] = await db
    .select()
    .from(scansTable)
    .where(eq(scansTable.id, params.data.id));

  if (!scan) {
    res.status(404).json({ error: "Scan not found" });
    return;
  }

  res.json(GetScanResponse.parse(scan));
});

router.delete("/scans/:id", async (req, res): Promise<void> => {
  const params = DeleteScanParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [scan] = await db
    .delete(scansTable)
    .where(eq(scansTable.id, params.data.id))
    .returning();

  if (!scan) {
    res.status(404).json({ error: "Scan not found" });
    return;
  }

  res.sendStatus(204);
});

export default router;
