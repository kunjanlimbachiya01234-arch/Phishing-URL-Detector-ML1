export type SignalSeverity = "low" | "medium" | "high";
export type Verdict = "safe" | "suspicious" | "phishing";

export interface Signal {
  id: string;
  label: string;
  severity: SignalSeverity;
  detail: string;
}

export interface AnalysisResult {
  normalizedUrl: string;
  domain: string;
  verdict: Verdict;
  riskScore: number;
  signals: Signal[];
}

const SUSPICIOUS_TLDS = new Set([
  "zip", "review", "country", "kim", "cricket", "science", "work",
  "party", "gq", "link", "tk", "ml", "ga", "cf", "top", "xyz",
  "click", "loan", "download", "men", "win", "bid", "stream", "icu",
]);

const URL_SHORTENERS = new Set([
  "bit.ly", "tinyurl.com", "t.co", "goo.gl", "ow.ly", "is.gd",
  "buff.ly", "rebrand.ly", "cutt.ly", "shorte.st", "tiny.cc",
]);

const BRAND_KEYWORDS = [
  "paypal", "apple", "microsoft", "amazon", "google", "facebook",
  "netflix", "bankofamerica", "wellsfargo", "chase", "instagram",
  "linkedin", "outlook", "office365", "coinbase", "binance", "irs",
  "usps", "fedex", "dhl", "ebay", "walmart",
];

const URGENCY_KEYWORDS = [
  "verify", "suspend", "urgent", "confirm", "secure", "update",
  "locked", "expire", "billing", "signin", "login", "account",
  "reset", "unusual", "alert", "immediately",
];

function addSignal(
  signals: Signal[],
  score: number,
  id: string,
  label: string,
  severity: SignalSeverity,
  detail: string,
): number {
  signals.push({ id, label, severity, detail });
  const weight = severity === "high" ? 30 : severity === "medium" ? 15 : 7;
  return score + weight;
}

export function analyzeUrl(rawUrl: string): AnalysisResult {
  let input = rawUrl.trim();
  if (!/^[a-zA-Z][a-zA-Z0-9+.-]*:\/\//.test(input)) {
    input = `http://${input}`;
  }

  let parsed: URL;
  try {
    parsed = new URL(input);
  } catch {
    throw new Error("The provided value is not a valid URL");
  }

  const signals: Signal[] = [];
  let score = 0;

  const hostname = parsed.hostname.toLowerCase();
  const fullUrl = parsed.toString();
  const path = parsed.pathname + parsed.search;

  const isIpHost = /^(\d{1,3}\.){3}\d{1,3}$/.test(hostname) || hostname.includes(":");
  if (isIpHost) {
    score = addSignal(
      signals,
      score,
      "ip-host",
      "IP address used as host",
      "high",
      "Legitimate sites almost never use a raw IP address instead of a domain name.",
    );
  }

  if (parsed.protocol !== "https:") {
    score = addSignal(
      signals,
      score,
      "no-https",
      "Not using HTTPS",
      "medium",
      "The link does not use a secure connection, which is common in phishing pages.",
    );
  }

  const labels = hostname.split(".");
  const subdomainCount = Math.max(0, labels.length - 2);
  if (subdomainCount >= 3) {
    score = addSignal(
      signals,
      score,
      "excess-subdomains",
      "Excessive subdomains",
      "medium",
      `The domain has ${subdomainCount} subdomains, a common trick to disguise the real host.`,
    );
  }

  const tld = labels[labels.length - 1] ?? "";
  if (SUSPICIOUS_TLDS.has(tld)) {
    score = addSignal(
      signals,
      score,
      "suspicious-tld",
      "Uncommon top-level domain",
      "medium",
      `The ".${tld}" domain extension is frequently abused for disposable phishing sites.`,
    );
  }

  if (URL_SHORTENERS.has(hostname)) {
    score = addSignal(
      signals,
      score,
      "url-shortener",
      "URL shortener detected",
      "medium",
      "Shortened links hide the real destination until you click them.",
    );
  }

  if (hostname.includes("xn--")) {
    score = addSignal(
      signals,
      score,
      "punycode",
      "Punycode / internationalized domain",
      "high",
      "The domain uses punycode encoding, a technique used to spoof lookalike characters in brand names.",
    );
  }

  if (hostname.split("-").length - 1 >= 3) {
    score = addSignal(
      signals,
      score,
      "many-hyphens",
      "Domain has many hyphens",
      "low",
      "A domain with several hyphens can be an attempt to mimic a trusted brand name.",
    );
  }

  const registrableDomain = labels.slice(-2).join(".");
  const matchedBrand = BRAND_KEYWORDS.find((brand) => hostname.includes(brand));
  if (matchedBrand && !registrableDomain.startsWith(`${matchedBrand}.`)) {
    score = addSignal(
      signals,
      score,
      "brand-lookalike",
      "Brand name in a non-official domain",
      "high",
      `The name "${matchedBrand}" appears in the domain, but the domain does not belong to that brand's official site.`,
    );
  }

  const lowerFullUrl = fullUrl.toLowerCase();
  const urgencyHits = URGENCY_KEYWORDS.filter((word) => lowerFullUrl.includes(word));
  if (urgencyHits.length >= 2) {
    score = addSignal(
      signals,
      score,
      "urgency-language",
      "Urgency or account-scare language",
      "medium",
      `The link contains pressure-oriented terms (${urgencyHits.slice(0, 3).join(", ")}) often used to rush victims.`,
    );
  }

  if (hostname.includes("@") || fullUrl.includes("@")) {
    score = addSignal(
      signals,
      score,
      "at-symbol",
      "'@' symbol in URL",
      "high",
      "URLs containing '@' can redirect to a different host than the one visibly displayed.",
    );
  }

  if (path.length > 100) {
    score = addSignal(
      signals,
      score,
      "long-path",
      "Unusually long path or query string",
      "low",
      "A very long path can be used to obscure the true intent of the link or encode tracking payloads.",
    );
  }

  const digitCount = (hostname.match(/\d/g) ?? []).length;
  if (digitCount >= 4) {
    score = addSignal(
      signals,
      score,
      "many-digits",
      "Domain contains many digits",
      "low",
      "A high density of digits in a domain name is unusual for legitimate brands.",
    );
  }

  if (signals.length === 0) {
    signals.push({
      id: "no-signals",
      label: "No red flags detected",
      severity: "low",
      detail: "The URL structure does not match common phishing patterns we check for.",
    });
  }

  const riskScore = Math.max(0, Math.min(100, score));
  const verdict: Verdict = riskScore >= 60 ? "phishing" : riskScore >= 25 ? "suspicious" : "safe";

  return {
    normalizedUrl: fullUrl,
    domain: hostname,
    verdict,
    riskScore,
    signals,
  };
}
